'use strict';

const { getPostgresClient } = require('./postgres');

/**
 * home
 * @param {*} event
 * @returns
 */
module.exports.condition = async (event) => {
  let res;
  const db = await getPostgresClient();
  const username = event.queryStringParameters.username;
  let startDate = event.queryStringParameters.startDate;
  const endDate = event.queryStringParameters.endDate;
  const orderBy = event.queryStringParameters.orderBy;

  try {
    // startDateの指定がなければ面談開始日からスタート
    if (!startDate) {
      let sql = ` SELECT interview_started_at
                    from users WHERE
                    pool_username = '${username}' `;
      const dRes = await db.execute(sql);
      let dt = new Date(dRes[0].interview_started_at);
      startDate = formatYYYYMMDD(dt);
    }

    let sql = ` SELECT * FROM conditions WHERE
                  pool_username = '${username}' AND
                  condition_date >= '${startDate}' AND 
                  condition_date <= '${endDate}' `;
    if (orderBy) {
      sql += `ORDER BY ${orderBy}`;
    }
    res = await db.execute(sql);
  } catch (e) {
    throw e;
  } finally {
    await db.release();
  }

  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        status: 200,
        results: res,
      },
      null,
      2
    ),
  };
};

/**
 * save
 * @param {*} event
 * @returns
 */
module.exports.save = async (event) => {
  let res;
  const db = await getPostgresClient();
  const body = JSON.parse(JSON.parse(JSON.stringify(event.body)));
  let sql = '';

  try {
    sql = ` SELECT interview_started_at
              from users WHERE
              pool_username = '${body.username}' `;
    const user = await db.execute(sql);
    let dt = user[0].interview_started_at;
    let strDt = '';
    if (dt) {
      const tmp_dt = new Date(dt);
      const y = tmp_dt.getFullYear();
      const m = tmp_dt.getMonth() + 1;
      const d = tmp_dt.getDate();
      const h = tmp_dt.getHours();
      const mm = tmp_dt.getMinutes();
      const s = tmp_dt.getSeconds();
      strDt = `${y}-${m}-${d} ${h}:${mm}:${s}`;
    }

    sql = ` SELECT * FROM conditions WHERE
              pool_username = '${body.username}' AND
              condition_date = '${body.date}' `;
    res = await db.execute(sql);

    if (res.length > 0) {
      body.weight = body.weight ? body.weight : res[0].weight;
      body.bp1 = body.bp1 ? body.bp1 : res[0].bp1;
      body.bp2 = body.bp2 ? body.bp2 : res[0].bp2;
      body.bp3 = body.bp3 ? body.bp3 : res[0].bp3;
      body.bp4 = body.bp4 ? body.bp4 : res[0].bp4;
      body.step = body.step ? body.step : res[0].step;
      sql = ` UPDATE conditions SET
                interview_started_at = '${strDt}',
                weight = ${body.weight},
                weight_updated_at = now(),
                bp1 = ${body.bp1},
                bp1_updated_at = now(),
                bp2 = ${body.bp2},
                bp2_updated_at = now(),
                bp3 = ${body.bp3},
                bp3_updated_at = now(),
                bp4 = ${body.bp4},
                bp4_updated_at = now(),
                step = ${body.step},
                step_updated_at = now(),
                updated_at = now()
                WHERE
                pool_username = '${body.username}' AND
                condition_date = '${body.date}'`;
    } else {
      body.weight = body.weight ? body.weight : null;
      body.bp1 = body.bp1 ? body.bp1 : null;
      body.bp2 = body.bp2 ? body.bp2 : null;
      body.bp3 = body.bp3 ? body.bp3 : null;
      body.bp4 = body.bp4 ? body.bp4 : null;
      body.step = body.step ? body.step : null;
      sql = ` INSERT INTO conditions(
                condition_date,
                pool_username,
                interview_started_at,
                weight,
                weight_updated_at,
                bp1,
                bp1_updated_at,
                bp2,
                bp2_updated_at,
                bp3,
                bp3_updated_at,
                bp4,
                bp4_updated_at,
                step,
                step_updated_at,
                updated_at,
                created_at)
                VALUES(
                  '${body.date}',
                  '${body.username}',
                  '${strDt}',
                  ${body.weight}, now(),
                  ${body.bp1}, now(),
                  ${body.bp2}, now(),
                  ${body.bp3}, now(),
                  ${body.bp4}, now(),
                  ${body.step}, now(),
                  now(),
                  now()) `;
    }
    await db.begin();
    res = await db.execute(sql);
    await db.commit();
  } catch (e) {
    await db.roleback();
    throw e;
  } finally {
    await db.release();
  }

  return {
    statusCode: 201,
    body: JSON.stringify(
      {
        status: 201,
        results: res,
      },
      null,
      2
    ),
  };
};

/**
 * graph_月集計
 * @param {*} graph
 * @returns
 */
module.exports.graph = async (event) => {
  let res = [];
  const db = await getPostgresClient();
  const username = event.queryStringParameters.username;
  const year = event.queryStringParameters.year;
  try {
    for (let i = 1; i <= 12; i++) {
      const zi = zeroPadding(i, 2);
      const startDate = year + zi + '01';
      const endDate = year + zi + '31';

      const sql =
        ` SELECT ` +
        ` AVG(weight) as weight, ` +
        ` AVG(bp1)    as bp1, ` +
        ` AVG(bp2)    as bp2, ` +
        ` AVG(bp3)    as bp3, ` +
        ` AVG(bp4)    as bp4, ` +
        ` SUM(step)   as step ` +
        ` FROM conditions WHERE ` +
        ` pool_username = '${username}' AND ` +
        ` condition_date >= '${startDate}' AND ` +
        ` condition_date <= '${endDate}'`;

      res.push(await db.execute(sql));
    }
  } catch (e) {
    throw e;
  } finally {
    await db.release();
  }

  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        status: 200,
        results: res,
      },
      null,
      2
    ),
  };
};

/**
 * 直近14日分のデータを取得
 * @param {*} graph_day
 * @returns
 */
module.exports.graph_day = async (event) => {
  let res;
  const db = await getPostgresClient();
  const username = event.queryStringParameters.username;
  const addDate = Number(event.queryStringParameters.addDate);

  // n日前の日付
  const dt1 = new Date();
  dt1.setDate(dt1.getDate() + addDate);
  const startDate = formatYYYYMMDD(dt1);

  // 本日の日付
  const dt2 = new Date();
  const endDate = formatYYYYMMDD(dt2);

  try {
    const sql =
      ` SELECT ` +
      ` condition_date, ` +
      ` weight, ` +
      ` bp1, ` +
      ` bp2, ` +
      ` bp3, ` +
      ` bp4, ` +
      ` step ` +
      ` FROM conditions WHERE ` +
      ` pool_username = '${username}' AND ` +
      ` condition_date >= '${startDate}' AND ` +
      ` condition_date <= '${endDate}' ` +
      ` ORDER BY condition_date `;
    res = await db.execute(sql);
  } catch (e) {
    throw e;
  } finally {
    await db.release();
  }

  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        status: 200,
        results: res,
      },
      null,
      2
    ),
  };
};

/**
 * graph_週集計
 * @param {*} graph_month
 * @returns
 */
module.exports.graph_month = async (event) => {
  let res = [];
  const db = await getPostgresClient();
  const username = event.queryStringParameters.username;
  let index = event.queryStringParameters.index;
  let max = event.queryStringParameters.max;

  // default
  index = index ? index : 0;
  max = max ? max : 24;

  try {
    let sql = ` SELECT interview_started_at
                  from users WHERE
                  pool_username = '${username}' `;
    const dRes = await db.execute(sql);

    let dt = new Date(dRes[0].interview_started_at);
    dt.setDate(dt.getDate() + max * 8 * index);
    let endDt = new Date(dRes[0].interview_started_at);
    endDt.setDate(dt.getDate() + 7);

    for (let i = 0; i < max; i++) {
      const y = dt.getFullYear();
      const m = zeroPadding(dt.getMonth() + 1, 2);
      const d = zeroPadding(dt.getDate(), 2);
      const startDate = y + m + d;

      const yy = endDt.getFullYear();
      const mm = zeroPadding(endDt.getMonth() + 1, 2);
      const dd = zeroPadding(endDt.getDate(), 2);
      const endDate = yy + mm + dd;

      sql =
        ` SELECT ` +
        ` AVG(weight) as weight, ` +
        ` AVG(bp1)    as bp1, ` +
        ` AVG(bp2)    as bp2, ` +
        ` AVG(bp3)    as bp3, ` +
        ` AVG(bp4)    as bp4, ` +
        ` AVG(step)   as step ` +
        ` FROM conditions WHERE ` +
        ` pool_username = '${username}' AND ` +
        ` condition_date >= '${startDate}' AND ` +
        ` condition_date <= '${endDate}'`;

      dt.setDate(dt.getDate() + 8);
      endDt.setDate(dt.getDate() + 7);

      res.push(await db.execute(sql));
    }
  } catch (e) {
    throw e;
  } finally {
    await db.release();
  }

  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        status: 200,
        results: res,
      },
      null,
      2
    ),
  };
};

/**
 * 0埋め
 * @param {*} num
 * @param {*} len
 * @returns
 */
function zeroPadding(num, len) {
  return (Array(len).join('0') + num).slice(-len);
}

/**
 * Date型をYYYYMMDDの形式に変換
 * @param {Date} dt
 * @returns
 */
function formatYYYYMMDD(dt) {
  const y = zeroPadding(dt.getFullYear(), 4);
  const m = zeroPadding(dt.getMonth() + 1, 2);
  const d = zeroPadding(dt.getDate(), 2);
  return y + m + d;
}
