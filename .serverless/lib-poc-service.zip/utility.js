const db = require('./db-client');

/**
 * 結果表示
 * @param {*} res
 * @param {*} body
 * @returns
 */
 module.exports.showResponce = (res, body) => {
  return {
    statusCode: res.code,
    body: JSON.stringify(
      {
        message: res.message,
        input: body,
      },
      null,
      2
    )
  };
}

/**
 * クエリ実行
 * @param {*} db
 * @param {*} query
 * @param {*} code
 * @returns
 */
module.exports.queryAsync = async (query, code) => {
  let res = {
    code: 0,
    message: null,
    body: null,
  };

  (async () => {
    try {
      const  con = await db.connect();
      await con.query(query)
        .then(x => {
          res.code = code;
          res.message = "success";
          res.body = x;
        })
        .catch(e => {
          res.code = 400;
          res.message = e.stack.error;
          res.body = e.stack;
          throw e;
        });
    } catch (err) {
      throw err;
    } finally {
      db.release();
    }
  })().catch(err => {
    console.error(err);
  });

  return new Promise(resolve => {
    resolve(res);
  });
}

/**
 * テーブルのレコード数を取得
 * @param {*} db
 * @param {*} tableName
 * @returns
 */
module.exports.getCountAsync = async (tableName) => {
  await db.connect();

  const query = {
    text: `SELECT * FROM ${tableName}`
  };

  let cnt = 0;
  await db.query(query)
    .then(res => cnt = res.rows.length)
    .catch(e => cnt = 0)

  return new Promise((resolve) => {
    resolve(cnt);
  });
}
